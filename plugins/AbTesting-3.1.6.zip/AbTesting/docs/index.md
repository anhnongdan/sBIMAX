## Documentation

The [A/B Testing User Guide](https://piwik.org/docs/ab-testing/) and the [A/B Testing FAQ](https://piwik.org/faq/ab-testing/) help you getting started in running A/B tests. 
The [A/B Testing developer guides](https://developer.piwik.org/guides/ab-tests) help you embedding and implementing A/B tests into your project.