<?php

return array(
    'entities.idNames' => DI\add(array('idExperiment'))
);
